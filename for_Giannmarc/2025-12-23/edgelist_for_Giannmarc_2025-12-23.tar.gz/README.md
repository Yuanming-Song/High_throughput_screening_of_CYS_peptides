# Random Peptide Sequence Edgelist Dataset

This directory contains an RDA file with 1000 edge lists for randomly selected peptide sequences.

## Data Construction

The dataset contains edgelists extracted from the final frame of MD simulations:
- **Monomer simulations**: 300 monomer peptides
- **Dimer simulations**: 150 dimer peptides (using single node representation)

Each monomeric peptide is represented as a node in the network. For dimer simulations, disulfide bonds are also considered as interpeptide interaction edges.

All edgelists have the same size of 300 nodes.

## Data Structure

The RDA file contains a nested list structure stored in a variable named `result`. To use the data:

```r
# Load the RDA file
load("random_sequences_edgelist.rda")

# Access edgelists using:
result[["monomer"]][["C_A"]]
result[["dimer"]][["A_C_A"]]
```

Where:
- `result` is the variable name (automatically loaded when using `load()`)
- `"monomer"` or `"dimer"` specifies the simulation state
- `"C_A"`, `"A_C_A"`, `"A_A_C_A"` etc. are sequence names (underscore-separated amino acids)

Each edgelist is extracted from the final frame (frame 202) of the corresponding MD simulation.

